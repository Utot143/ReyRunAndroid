package com.reyrun.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private AppDb dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = new AppDb();
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0B1020);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new ReyRunBridge(), "ReyRunNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppDb extends SQLiteOpenHelper {
        AppDb() { super(MainActivity.this, "reyrun.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, note TEXT NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}
    }

    private class ReyRunBridge {
        @JavascriptInterface
        public String saveFile(String name, String content) {
            try {
                String safe = safeName(name);
                File dir = new File(getFilesDir(), "projects");
                if (!dir.exists()) dir.mkdirs();
                File target = new File(dir, safe);
                try (FileOutputStream out = new FileOutputStream(target)) {
                    out.write(content.getBytes(StandardCharsets.UTF_8));
                }
                return "Saved " + safe + " inside ReyRun.";
            } catch (Exception e) {
                return "Save failed: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public String loadFile(String name) {
            try {
                File target = new File(new File(getFilesDir(), "projects"), safeName(name));
                if (!target.exists()) return "";
                byte[] bytes = new byte[(int) target.length()];
                try (FileInputStream in = new FileInputStream(target)) {
                    int n = in.read(bytes);
                    return new String(bytes, 0, Math.max(0, n), StandardCharsets.UTF_8);
                }
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public String listFiles() {
            JSONArray arr = new JSONArray();
            File dir = new File(getFilesDir(), "projects");
            File[] files = dir.listFiles();
            if (files != null) for (File f : files) if (f.isFile()) arr.put(f.getName());
            return arr.toString();
        }

        @JavascriptInterface
        public String runSql(String sql) {
            JSONArray rows = new JSONArray();
            JSONObject result = new JSONObject();
            Cursor cursor = null;
            try {
                String trimmed = sql == null ? "" : sql.trim();
                if (trimmed.isEmpty()) return "{\"ok\":false,\"message\":\"Enter a SQL statement.\"}";
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                if (trimmed.toLowerCase().startsWith("select") ||
                    trimmed.toLowerCase().startsWith("pragma") ||
                    trimmed.toLowerCase().startsWith("with")) {
                    cursor = db.rawQuery(trimmed, null);
                    JSONArray columns = new JSONArray();
                    for (int i = 0; i < cursor.getColumnCount(); i++) columns.put(cursor.getColumnName(i));
                    while (cursor.moveToNext()) {
                        JSONArray row = new JSONArray();
                        for (int i = 0; i < cursor.getColumnCount(); i++) {
                            row.put(cursor.isNull(i) ? JSONObject.NULL : cursor.getString(i));
                        }
                        rows.put(row);
                    }
                    result.put("ok", true);
                    result.put("columns", columns);
                    result.put("rows", rows);
                    result.put("message", rows.length() + " row(s) returned.");
                } else {
                    db.execSQL(trimmed);
                    result.put("ok", true);
                    result.put("columns", new JSONArray());
                    result.put("rows", new JSONArray());
                    result.put("message", "SQL command executed.");
                }
            } catch (Exception e) {
                try { result.put("ok", false); result.put("message", e.getMessage()); } catch (Exception ignored) {}
            } finally {
                if (cursor != null) cursor.close();
            }
            return result.toString();
        }

        private String safeName(String name) {
            if (name == null || name.trim().isEmpty()) return "index.html";
            String safe = name.replace("\\", "_").replace("/", "_").replace("..", "_");
            return safe.replaceAll("[^A-Za-z0-9._-]", "_");
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
