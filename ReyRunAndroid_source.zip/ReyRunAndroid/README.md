# ReyRun Android starter

This is a buildable Android project for a first ReyRun prototype.

## Included
- WebView-based HTML/CSS/JavaScript editor and preview
- Native private app storage for saving/opening project files
- Native SQLite database access through the SQL tab
- GitHub Actions workflow to build a debug APK without a local PC

## Not included yet
- A PHP runtime. The app does not execute PHP files in this version.
- Production signing. The generated debug APK is for testing.

## Build on a phone using GitHub
1. Create a GitHub account if needed.
2. Create a new repository named `ReyRunAndroid`.
3. Upload all files and folders from this project to the repository root.
4. Open the repository's **Actions** tab and allow workflows if prompted.
5. Select **Build ReyRun APK** and tap **Run workflow** (or push to `main`).
6. Open the completed workflow run, scroll to **Artifacts**, and download `ReyRun-debug-apk`.
7. Extract the ZIP and install `app-debug.apk`. Android may ask you to allow installs from that browser/file manager.

The workflow builds the APK in GitHub's cloud. No PC is required, but internet access and a GitHub account are needed.

## Important
This is an initial prototype. The SQL manager executes statements against a local SQLite database. Use only trusted SQL. Files are kept in the app's private storage and are not exported to Downloads yet.
